import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class CompanyJunit {

CompanyBO companyBO;

@Test
public void testValidDiscount() {

assertEquals("Datex shipping offers discount", companyBO.hasDiscount(95, 550));
assertEquals("Datex shipping offers discount", companyBO.hasDiscount(101, 400));
assertEquals("Datex shipping offers discount", companyBO.hasDiscount(150, 450));
assertEquals("Datex shipping offers discount", companyBO.hasDiscount(99, 550));

}

@Test
public void testInvalidDiscount() {
assertEquals("Datex shipping offers no discount", companyBO.hasDiscount(102, 501));
assertEquals("Datex shipping offers no discount", companyBO.hasDiscount(100, 500));
assertEquals("Datex shipping offers no discount", companyBO.hasDiscount(101, 500));
}

@Before
public void createObjectForCompanyBO() {
companyBO = new CompanyBO();
}
}

