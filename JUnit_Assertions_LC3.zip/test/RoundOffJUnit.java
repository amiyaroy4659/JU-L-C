import static org.junit.Assert.*;
import java.text.ParseException;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;


public class RoundOffJUnit {
RoundOffBO roundOffBO;
int value;

@Before
public void createObjectForRoundOffBO() {
roundOffBO = new RoundOffBO();
}
@Test
public void testRoundOffValue() {
value = roundOffBO.getRoundOffValue(61);
assertEquals(60,value);
value = roundOffBO.getRoundOffValue(63);
assertEquals(60,value);
value = roundOffBO.getRoundOffValue(64);
assertEquals(60,value);
value = roundOffBO.getRoundOffValue(75);
assertEquals(80,value);
value = roundOffBO.getRoundOffValue(76);
assertEquals(80,value);
value = roundOffBO.getRoundOffValue(78);
assertEquals(80,value);
value = roundOffBO.getRoundOffValue(79);
assertEquals(80,value);
value = roundOffBO.getRoundOffValue(80);
assertEquals(80,value);
}
}